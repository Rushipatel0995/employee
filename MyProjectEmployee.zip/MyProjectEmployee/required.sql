CREATE TABLE rushiemployee (empid number, empname varchar2(30), empDob date, salary number(5,2), designation varchar2(20));

CREATE SEQUENCE e_seq START WITH 1010;