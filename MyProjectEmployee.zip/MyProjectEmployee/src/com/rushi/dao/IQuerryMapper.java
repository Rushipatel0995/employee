package com.rushi.dao;

public interface IQuerryMapper {
	public static final String INSERT_EMPLOYEE="INSERT INTO rushiemployee VALUES(e_seq.nextval,?,?,?,?)";
	public static final String VIEWALL_EMPLOYEE="SELECT * FROM rushiemployee";
	public static final String VIEW_EMPLOYEE="SELECT * FROM rushiemployee WHERE empid=?";
	public static final String DELETE_EMPLOYEE="DELETE FROM rushiemployee WHERE empid=?";
	//public static final String Sequence="select play_seq.nextval from dual";
	public static final String UPDATE_EMPLOYEE="UPDATE rushiemployee SET SALARY = ?  WHERE empid=?";
}
