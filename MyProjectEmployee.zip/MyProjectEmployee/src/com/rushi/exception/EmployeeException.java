package com.rushi.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2719213500355855879L;
	
	public EmployeeException(){
		super();
	}
	public EmployeeException(String message){
		super(message);
	}
}
