package com.rushi.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rushi.bean.EmployeeBean;
import com.rushi.exception.EmployeeException;
import com.rushi.service.EmployeeServiceImpl;
import com.rushi.service.IEmployeeService;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("*.obj")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IEmployeeService empService = new EmployeeServiceImpl();
		EmployeeBean empBean = new EmployeeBean();
		
		String target = "";
		
		HttpSession session = request.getSession(true);
		
		String TargetInsert		 = "/pages/insertEmployee.jsp";
		String TargetSuccess	 = "/pages/success.jsp";
		String targetSearch 	 = "/pages/searchEmployee.jsp";
		String targetViewAll 	 = "/pages/viewAll.jsp";
		String targetError       = "/pages/error.jsp";
		String targetHome        = "index.jsp";
		
		String path = request.getServletPath().trim();
		
switch(path){
		
		case "/Home.obj" :
			session.setAttribute("error", null);
			session.setAttribute("employee", null);
			target = "index.jsp";
			break;

case "/add.obj":
	target=TargetInsert;
	break;
case "/insert.obj":
	//String da = request.getParameter("dob")
	try {
		//empBean.setEmpId(Integer.parseInt(request.getParameter("empId")));
		empBean.setEmpName(request.getParameter("empName"));
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate ld=LocalDate.parse(request.getParameter("empDob"), formatter);
		
		empBean.setDesignation(request.getParameter("designation"));
		empBean.setEmpDob(ld);
		empBean.setSalary(Double.parseDouble(request.getParameter("salary")));
		boolean inserted=empService.insertEmployee(empBean);
		if(inserted){
			target=TargetSuccess;
		}
	} catch (NumberFormatException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	} catch (EmployeeException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());

	}
	
	break;
case "/viewAll.obj" :
	try {
		List<EmployeeBean> list = empService.getAllEmployee();
		session.setAttribute("employees", list);
		target=targetViewAll;
	} catch (EmployeeException e) {
		
		e.printStackTrace();
	}
	break;
case "/search.obj" :
	target=targetSearch;
	break;
case "/searchEmployee.obj" :
	
	try {
		empBean = empService.searchEmployee(Integer.parseInt(request.getParameter("empId")));
		List<EmployeeBean> list2 = new ArrayList<EmployeeBean>();
		list2.add(empBean);
		session.setAttribute("employees", list2);
		target=targetViewAll;
	} catch (NumberFormatException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	} catch (EmployeeException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	}
	
	break;
case "/delete.obj" :
	target="/pages/delete.jsp";
	break;
case "/deleteEmployee.obj" :
	try {
		empService.deleteEmployee(Integer.parseInt(request.getParameter("empId")));
		target=TargetSuccess;
	} catch (NumberFormatException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	} catch (EmployeeException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	}
	
	break;
	
case "/update.obj":
	target="/pages/update.jsp";
	break;
	
case "/updateEmployee.obj":
	
	try {
		
		boolean isUpdated=empService.updateSal(Integer.parseInt(request.getParameter("empId")), Double.parseDouble(request.getParameter("salary")));
		
		
		session.setAttribute("employees1", isUpdated);
		if(isUpdated){
			target=TargetSuccess;
			
		}
		else
		{
			target=targetError;
		}
		
	} catch (NumberFormatException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	} catch (EmployeeException e) {
		target = targetError;
		request.setAttribute("message", e.getMessage());
	}
	break;
	
		
	}
RequestDispatcher dispatcher = request.getRequestDispatcher(target);
dispatcher.forward(request, response);
}
	
}
