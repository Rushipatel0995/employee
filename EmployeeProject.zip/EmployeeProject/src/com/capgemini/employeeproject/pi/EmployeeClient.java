package com.capgemini.employeeproject.pi;

import java.util.Scanner;
import com.capgemini.employeeproject.bean.Employee;

public class EmployeeClient {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee();
	}
}
