package com.capgemini.employeeproject.dao;

public interface EmployeeQueryMapper
{
	public static final String INSERT_EMPLOYEE= "INSERT INTO employees VALUES(emp_id_seq.NEXTVAL,?,?,?,?)";
	public static final String DELETE_EMPLOYEE = "DELETE FROM employees WHERE id=?";
	public static final String VIEW_ALL = "SELECT * FROM employees";
	public static final String UPDATE_EMPLOYEE = "UPDATE TABLE employees SET salary=? WHERE id=?";
}
