package com.capgemini.employeeproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.employeeproject.bean.Employee;
import com.capgemini.employeeproject.exception.EmployeeException;
import com.capgemini.employeeproject.util.DBConnection;

public class EmployeeDAO implements IEmployeeDAO {

	@Override
	public String insert(Employee e) throws EmployeeException 
	{
		try (Connection conn = DBConnection.getInstance().getConnection();
			 PreparedStatement ps=conn.prepareStatement(EmployeeQueryMapper.INSERT_EMPLOYEE);)
		{
			
			String eid=null;
			ResultSet resultSet = null;
			ps.setString(2, e.getName());
			ps.setString(3, e.getDesgn());
			ps.setFloat(4, e.getSalary());
			ps.setString(5, e.getDept());
			
			resultSet=ps.executeQuery();
			if(resultSet.next())
				eid=resultSet.getString(1);
			
			return eid;
				
		}catch (SQLException e1) {
			
			System.err.print("SQL Error");
			throw new EmployeeException("System Error Occured.");
		}
	}

	@Override
	public boolean delete(Employee e) throws EmployeeException{
		try (Connection conn = DBConnection.getInstance().getConnection();
				 PreparedStatement ps=conn.prepareStatement(EmployeeQueryMapper.DELETE_EMPLOYEE);){
			ps.setInt(1, e.getId());
			int queryResult = ps.executeUpdate();
			
			if (queryResult > 0)
				return true;
			else
				return false;
		}catch(SQLException e1){
			System.err.print("SQL Error");
			throw new EmployeeException("System Error Occured.");
		}
	}

	@Override
	public boolean update(Employee e) throws EmployeeException {
		try (Connection conn = DBConnection.getInstance().getConnection();
				 PreparedStatement ps=conn.prepareStatement(EmployeeQueryMapper.UPDATE_EMPLOYEE);){
			ps.setFloat(1, e.getSalary());
			ps.setInt(2, e.getId());
			int queryResult = ps.executeUpdate();
			
			if (queryResult > 0)
				return true;
			else
				return false;
		}catch(SQLException e1){
			System.err.print("SQL Error");
			throw new EmployeeException("System Error Occured.");
		}
	}

	@Override
	public List<Employee> view() throws EmployeeException {
		List<Employee>eList = new ArrayList<Employee>();
		try (Connection conn = DBConnection.getInstance().getConnection();
				 PreparedStatement ps=conn.prepareStatement(EmployeeQueryMapper.VIEW_ALL)){
			int records= 0;
			ResultSet resultset=ps.executeQuery();
			
			while(resultset.next()){	
				Employee emp1 = new Employee();
				emp1.setId(resultset.getInt(1));
				emp1.setName(resultset.getString(2));
				emp1.setDesgn(resultset.getString(3));
				emp1.setSalary(resultset.getFloat(4));
				emp1.setDept(resultset.getString(5));
				eList.add(emp1);
				records++;
			}	
			System.out.println("Records Returned"+records);
		}catch(SQLException sqlException) {
			System.err.print(sqlException.getMessage());
			throw new EmployeeException("System Error Occured.");
		}
		return eList;
	}
}