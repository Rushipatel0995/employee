package com.capgemini.employeeproject.dao;

import java.util.List;

import com.capgemini.employeeproject.bean.Employee;
import com.capgemini.employeeproject.exception.EmployeeException;

public interface IEmployeeDAO 
{
	public String insert(Employee e) throws EmployeeException;
	public boolean delete(Employee e) throws EmployeeException;
	public boolean update(Employee e) throws EmployeeException;
	public List<Employee> view() throws EmployeeException;
}
