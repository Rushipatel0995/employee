package com.capgemini.employeeproject.exception;

public class EmployeeException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -679675780620390621L;

	public EmployeeException(String message) {
		super(message);
	}
}
