package com.capgemini.employeeproject.service;

import com.capgemini.employeeproject.bean.Employee;
import com.capgemini.employeeproject.exception.EmployeeException;

public interface IEmployeeService{
	public String getEmployeeDetails(Employee e) throws EmployeeException;
	public void viewEmployeeDetails() throws EmployeeException;
	public void deleteEmployeeDetails() throws EmployeeException;
	public void updateEmployeeDetails() throws EmployeeException;
}
