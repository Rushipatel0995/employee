package com.capgemini.employeeproject.service;

import com.capgemini.employeeproject.bean.Employee;
import com.capgemini.employeeproject.dao.EmployeeDAO;
import com.capgemini.employeeproject.dao.IEmployeeDAO;
import com.capgemini.employeeproject.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {
	IEmployeeDAO employeeDAO;
	@Override
	public String getEmployeeDetails(Employee e) throws EmployeeException {
		employeeDAO = new EmployeeDAO();	
		String eId;
		eId = employeeDAO.insert(e);
		return eId;
	}

	@Override
	public void viewEmployeeDetails() throws EmployeeException {

	}

	@Override
	public void deleteEmployeeDetails() throws EmployeeException {

	}

	@Override
	public void updateEmployeeDetails() throws EmployeeException {
		
	}

}
